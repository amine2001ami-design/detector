خطوات التشغيل
1) نزّل النموذج من الرابط التالي وضعه في app/src/main/assets/ بهذا الاسم تماماً:
   https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float32/1/efficientdet_lite0.tflite
2) افتح المجلد في Android Studio (Koala أو أحدث) واتركه يزامن Gradle.
3) وصّل هاتفك مع تفعيل USB debugging ثم اضغط Run.
   لإنشاء ملف APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
