package com.example.detector

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.components.containers.Detection
import kotlin.math.max

class OverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    private var detections: List<Detection> = emptyList()
    private var imgW = 1
    private var imgH = 1

    private val box = Paint().apply {
        color = Color.parseColor("#5CF2C4"); style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val tag = Paint().apply { color = Color.parseColor("#5CF2C4") }
    private val text = Paint().apply {
        color = Color.parseColor("#06201A"); textSize = 42f; isFakeBoldText = true; isAntiAlias = true
    }

    fun setResults(list: List<Detection>, w: Int, h: Int) {
        detections = list; imgW = w; imgH = h
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        // PreviewView يستخدم FILL_CENTER افتراضياً، فنطابق نفس القياس
        val scale = max(width.toFloat() / imgW, height.toFloat() / imgH)
        val dx = (width - imgW * scale) / 2f
        val dy = (height - imgH * scale) / 2f
        for (d in detections) {
            val b = d.boundingBox()
            val r = RectF(b.left * scale + dx, b.top * scale + dy, b.right * scale + dx, b.bottom * scale + dy)
            canvas.drawRect(r, box)
            val c = d.categories().firstOrNull() ?: continue
            val label = "${c.categoryName()} ${(c.score() * 100).toInt()}%"
            val tw = text.measureText(label) + 20f
            val th = 56f
            val top = if (r.top - th < 0) r.top else r.top - th
            canvas.drawRect(r.left, top, r.left + tw, top + th, tag)
            canvas.drawText(label, r.left + 10f, top + 40f, text)
        }
    }
}
