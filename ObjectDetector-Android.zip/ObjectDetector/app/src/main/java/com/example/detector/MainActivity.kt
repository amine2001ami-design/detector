package com.example.detector

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.os.SystemClock
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: OverlayView
    private lateinit var count: TextView
    private lateinit var executor: ExecutorService
    private var detector: ObjectDetector? = null

    private val askCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else {
            Toast.makeText(this, "إذن الكاميرا مطلوب لتشغيل التطبيق", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.preview)
        overlay = findViewById(R.id.overlay)
        count = findViewById(R.id.count)
        executor = Executors.newSingleThreadExecutor()

        try {
            setupDetector()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذّر تحميل النموذج. تأكد من وجود efficientdet_lite0.tflite في مجلد assets", Toast.LENGTH_LONG).show()
            finish(); return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
            startCamera() else askCamera.launch(Manifest.permission.CAMERA)
    }

    private fun setupDetector() {
        val options = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("efficientdet_lite0.tflite").build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setScoreThreshold(0.5f)
            .setMaxResults(10)
            .setResultListener { result, input ->
                val list = result.detections()
                overlay.setResults(list, input.width, input.height)
                runOnUiThread { count.text = "الأجسام المكتشفة: ${list.size}" }
            }
            .setErrorListener { e -> e.printStackTrace() }
            .build()
        detector = ObjectDetector.createFromOptions(this, options)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, previewUseCase, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        val rotation = proxy.imageInfo.rotationDegrees
        val raw = proxy.toBitmap()
        proxy.close()
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val bitmap = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
        detector?.detectAsync(BitmapImageBuilder(bitmap).build(), SystemClock.uptimeMillis())
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        detector?.close()
    }
}
